<?php
/**
 * File: index.php
 * Halaman Beranda / Dashboard: ringkasan data menu & pesanan.
 */
require_once 'config/koneksi.php';
$judul_halaman = 'Beranda';

// ---------------------------------------------------------
// 1. Ambil data statistik (query tanpa input user -> aman memakai mysqli_query)
// ---------------------------------------------------------
$total_menu      = mysqli_fetch_row(mysqli_query($koneksi, "SELECT COUNT(*) FROM menu"))[0];
$total_pesanan   = mysqli_fetch_row(mysqli_query($koneksi, "SELECT COUNT(*) FROM pesanan"))[0];
$pesanan_proses  = mysqli_fetch_row(mysqli_query($koneksi, "SELECT COUNT(*) FROM pesanan WHERE status = 'Diproses'"))[0];
$total_pendapatan = mysqli_fetch_row(mysqli_query($koneksi, "SELECT COALESCE(SUM(total_harga), 0) FROM pesanan WHERE status = 'Selesai'"))[0];

// ---------------------------------------------------------
// 2. Ambil 5 pesanan terbaru (JOIN ke tabel menu untuk mengambil nama menu)
// ---------------------------------------------------------
$pesanan_terbaru = mysqli_query($koneksi, "
    SELECT p.id_pesanan, p.nama_pelanggan, p.jumlah, p.total_harga, p.status, m.nama_menu
    FROM pesanan p
    JOIN menu m ON p.id_menu = m.id_menu
    ORDER BY p.tanggal_pesan DESC
    LIMIT 5
");

// ---------------------------------------------------------
// 3. Ambil menu yang stoknya menipis (stok <= 5)
// ---------------------------------------------------------
$stok_menipis = mysqli_query($koneksi, "SELECT nama_menu, stok FROM menu WHERE stok <= 5 ORDER BY stok ASC");

include 'includes/header.php';
?>

<!-- Bagian sambutan -->
<section class="hero mb-4 card-app">
    <span class="badge bg-light text-dark mb-2"><i class="bi bi-calendar3 me-1"></i><?= date('d M Y') ?></span>
    <h1>Selamat datang di Warung Kita 👋</h1>
    <p>Kelola daftar menu dan pesanan pelanggan dengan mudah. Total harga dan stok dihitung otomatis.</p>
    <div class="d-flex flex-wrap gap-2 mt-3">
        <a id="btn-hero-pesan" href="pesanan/tambah.php" class="btn btn-primer"><i class="bi bi-plus-lg me-1"></i> Buat Pesanan</a>
        <a id="btn-hero-menu" href="menu/tambah.php" class="btn btn-light"><i class="bi bi-journal-plus me-1"></i> Tambah Menu</a>
    </div>
    <span class="emoji d-none d-md-block">🍜</span>
</section>

<!-- Kartu statistik -->
<div class="row g-3 mb-4">
    <div class="col-6 col-lg-3">
        <div class="card card-app stat-card">
            <div class="stat-ikon" style="background:#fff0e8;color:#ff6b35"><i class="bi bi-journal-text"></i></div>
            <div><small>Total Menu</small><h3><?= (int) $total_menu ?></h3></div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card card-app stat-card">
            <div class="stat-ikon" style="background:#e6f0ff;color:#2b5fd9"><i class="bi bi-receipt"></i></div>
            <div><small>Total Pesanan</small><h3><?= (int) $total_pesanan ?></h3></div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card card-app stat-card">
            <div class="stat-ikon" style="background:#fff4e0;color:#c77700"><i class="bi bi-hourglass-split"></i></div>
            <div><small>Sedang Diproses</small><h3><?= (int) $pesanan_proses ?></h3></div>
        </div>
    </div>
    <div class="col-6 col-lg-3">
        <div class="card card-app stat-card">
            <div class="stat-ikon" style="background:#e3f8ec;color:#18864b"><i class="bi bi-cash-stack"></i></div>
            <div><small>Pendapatan</small><h3><?= rupiah($total_pendapatan) ?></h3></div>
        </div>
    </div>
</div>

<div class="row g-4">
    <!-- Tabel pesanan terbaru -->
    <div class="col-lg-8">
        <div class="card card-app h-100">
            <div class="card-body pb-0 d-flex justify-content-between align-items-center">
                <h2 class="h6 fw-semibold mb-0">Pesanan Terbaru</h2>
                <a href="pesanan/index.php" class="small text-decoration-none">Lihat semua &rarr;</a>
            </div>
            <div class="table-responsive mt-3">
                <table class="table table-app">
                    <thead>
                        <tr><th>Pelanggan</th><th>Menu</th><th>Jumlah</th><th>Total</th><th>Status</th></tr>
                    </thead>
                    <tbody>
                    <?php if (mysqli_num_rows($pesanan_terbaru) === 0): ?>
                        <tr><td colspan="5" class="text-center teks-abu py-4">Belum ada pesanan.</td></tr>
                    <?php endif; ?>
                    <?php while ($baris = mysqli_fetch_assoc($pesanan_terbaru)): ?>
                        <tr>
                            <td class="fw-medium"><?= htmlspecialchars($baris['nama_pelanggan']) ?></td>
                            <td><?= htmlspecialchars($baris['nama_menu']) ?></td>
                            <td><?= (int) $baris['jumlah'] ?></td>
                            <td><?= rupiah($baris['total_harga']) ?></td>
                            <td><?= badge_status($baris['status']) ?></td>
                        </tr>
                    <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Daftar stok menipis -->
    <div class="col-lg-4">
        <div class="card card-app h-100">
            <div class="card-body">
                <h2 class="h6 fw-semibold mb-3"><i class="bi bi-exclamation-circle text-danger me-1"></i> Stok Menipis</h2>
                <?php if (mysqli_num_rows($stok_menipis) === 0): ?>
                    <p class="teks-abu mb-0">Semua stok aman 👍</p>
                <?php endif; ?>
                <ul class="list-group list-group-flush">
                <?php while ($menu = mysqli_fetch_assoc($stok_menipis)): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center px-0">
                        <?= htmlspecialchars($menu['nama_menu']) ?>
                        <span class="badge-soft <?= $menu['stok'] == 0 ? 'badge-soft-danger' : 'badge-soft-warning' ?>">
                            <?= (int) $menu['stok'] ?> tersisa
                        </span>
                    </li>
                <?php endwhile; ?>
                </ul>
            </div>
        </div>
    </div>
</div>

<?php include 'includes/footer.php'; ?>
