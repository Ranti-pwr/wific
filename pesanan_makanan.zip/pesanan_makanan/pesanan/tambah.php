<?php
/**
 * File: pesanan/tambah.php
 * CREATE - Membuat pesanan baru.
 * - Total harga dihitung otomatis (harga x jumlah)
 * - Stok menu berkurang otomatis
 */
require_once '../config/koneksi.php';
$judul_halaman = 'Buat Pesanan';

$id_menu = $nama_pelanggan = $jumlah = '';
$daftar_error = [];

// ---------------------------------------------------------
// PROSES FORM
// ---------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Ambil input
    $id_menu        = trim($_POST['id_menu'] ?? '');
    $nama_pelanggan = trim($_POST['nama_pelanggan'] ?? '');
    $jumlah         = trim($_POST['jumlah'] ?? '');

    // 2. Validasi input kosong / format
    if ($id_menu === '') {
        $daftar_error[] = 'Menu wajib dipilih.';
    }
    if ($nama_pelanggan === '') {
        $daftar_error[] = 'Nama pelanggan wajib diisi.';
    }
    if ($jumlah === '') {
        $daftar_error[] = 'Jumlah wajib diisi.';
    } elseif (!ctype_digit($jumlah) || (int) $jumlah <= 0) {
        $daftar_error[] = 'Jumlah harus berupa angka lebih dari 0.';
    }

    // 3. Ambil data menu yang dipilih (untuk harga & cek stok)
    $menu_dipilih = null;
    if (empty($daftar_error)) {
        $stmt = mysqli_prepare($koneksi, "SELECT id_menu, nama_menu, harga, stok FROM menu WHERE id_menu = ?");
        $id_menu_angka = (int) $id_menu;
        mysqli_stmt_bind_param($stmt, 'i', $id_menu_angka);
        mysqli_stmt_execute($stmt);
        $menu_dipilih = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

        if (!$menu_dipilih) {
            $daftar_error[] = 'Menu yang dipilih tidak ditemukan.';
        } elseif ((int) $jumlah > $menu_dipilih['stok']) {
            // Validasi: jumlah tidak boleh melebihi stok
            $daftar_error[] = 'Jumlah melebihi stok. Stok "' . $menu_dipilih['nama_menu'] . '" tersisa ' . $menu_dipilih['stok'] . '.';
        }
    }

    // 4. Simpan pesanan + kurangi stok
    if (empty($daftar_error)) {
        $jumlah_angka = (int) $jumlah;
        $total_harga  = $menu_dipilih['harga'] * $jumlah_angka;   // hitung total otomatis

        // Transaksi: kedua query harus berhasil semua, atau dibatalkan semua
        mysqli_begin_transaction($koneksi);
        try {
            // a. Kurangi stok (syarat "stok >= jumlah" mencegah stok menjadi minus)
            $stmt = mysqli_prepare($koneksi, "UPDATE menu SET stok = stok - ? WHERE id_menu = ? AND stok >= ?");
            mysqli_stmt_bind_param($stmt, 'iii', $jumlah_angka, $id_menu_angka, $jumlah_angka);
            mysqli_stmt_execute($stmt);
            if (mysqli_stmt_affected_rows($stmt) === 0) {
                throw new Exception('Stok tidak mencukupi.');
            }

            // b. Simpan data pesanan (status awal: Diproses)
            $stmt = mysqli_prepare($koneksi,
                "INSERT INTO pesanan (id_menu, nama_pelanggan, jumlah, total_harga, status) VALUES (?, ?, ?, ?, 'Diproses')");
            mysqli_stmt_bind_param($stmt, 'isii', $id_menu_angka, $nama_pelanggan, $jumlah_angka, $total_harga);
            mysqli_stmt_execute($stmt);

            mysqli_commit($koneksi);
            set_pesan('success', 'Pesanan atas nama "' . $nama_pelanggan . '" berhasil dibuat. Total: ' . rupiah($total_harga));
            arahkan_ke('index.php');
        } catch (Exception $e) {
            mysqli_rollback($koneksi);   // batalkan semua perubahan
            $daftar_error[] = 'Gagal menyimpan pesanan: ' . $e->getMessage();
        }
    }
}

// Ambil daftar menu yang stoknya masih ada untuk dropdown
$daftar_menu = mysqli_query($koneksi, "SELECT id_menu, nama_menu, kategori, harga, stok FROM menu WHERE stok > 0 ORDER BY kategori, nama_menu");

include '../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1>Buat Pesanan</h1>
        <p>Pilih menu, isi nama pelanggan dan jumlah pesanan.</p>
    </div>
    <a href="index.php" class="btn btn-light-app"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
</div>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card card-app">
            <div class="card-body p-4">

                <?php if (!empty($daftar_error)): ?>
                    <div class="alert alert-danger alert-app">
                        <strong><i class="bi bi-exclamation-triangle-fill me-1"></i> Pesanan gagal:</strong>
                        <ul class="mb-0 mt-1">
                            <?php foreach ($daftar_error as $error): ?>
                                <li><?= htmlspecialchars($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="post" id="form-tambah-pesanan">
                    <div class="mb-3">
                        <label for="id_menu" class="form-label">Menu</label>
                        <select id="id_menu" name="id_menu" class="form-select" required>
                            <option value="" data-harga="0" data-stok="0">-- Pilih Menu --</option>
                            <?php while ($menu = mysqli_fetch_assoc($daftar_menu)): ?>
                                <!-- data-harga & data-stok dipakai JavaScript untuk menghitung perkiraan total -->
                                <option value="<?= (int) $menu['id_menu'] ?>"
                                        data-harga="<?= (int) $menu['harga'] ?>"
                                        data-stok="<?= (int) $menu['stok'] ?>"
                                        <?= $id_menu == $menu['id_menu'] ? 'selected' : '' ?>>
                                    <?= htmlspecialchars($menu['nama_menu']) ?> — <?= rupiah($menu['harga']) ?> (stok: <?= (int) $menu['stok'] ?>)
                                </option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="nama_pelanggan" class="form-label">Nama Pelanggan</label>
                        <input type="text" id="nama_pelanggan" name="nama_pelanggan" class="form-control" maxlength="100"
                               placeholder="Contoh: Budi Santoso" value="<?= htmlspecialchars($nama_pelanggan) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="jumlah" class="form-label">Jumlah</label>
                        <input type="number" id="jumlah" name="jumlah" class="form-control" min="1"
                               placeholder="1" value="<?= htmlspecialchars($jumlah) ?>" required>
                        <div id="info-stok" class="form-text"></div>
                    </div>

                    <!-- Perkiraan total (hanya tampilan; total sebenarnya dihitung ulang di server) -->
                    <div class="p-3 rounded-3 mb-3 d-flex justify-content-between align-items-center" style="background:#fff7f3">
                        <span class="teks-abu">Total Harga</span>
                        <strong id="tampil-total" class="fs-5" style="color:var(--primer)">Rp 0</strong>
                    </div>

                    <div class="d-flex gap-2 justify-content-end">
                        <a href="index.php" class="btn btn-light-app">Batal</a>
                        <button id="btn-simpan-pesanan" type="submit" class="btn btn-primer"><i class="bi bi-cart-check me-1"></i> Simpan Pesanan</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

<script>
    // Hitung perkiraan total harga secara langsung saat menu/jumlah diubah
    const pilihMenu   = document.getElementById('id_menu');
    const inputJumlah = document.getElementById('jumlah');
    const tampilTotal = document.getElementById('tampil-total');
    const infoStok    = document.getElementById('info-stok');

    function hitungTotal() {
        const opsi   = pilihMenu.options[pilihMenu.selectedIndex];
        const harga  = parseInt(opsi.dataset.harga) || 0;
        const stok   = parseInt(opsi.dataset.stok) || 0;
        const jumlah = parseInt(inputJumlah.value) || 0;

        // Batasi input jumlah sesuai stok
        if (stok > 0) {
            inputJumlah.max = stok;
            infoStok.textContent = 'Stok tersedia: ' + stok;
            infoStok.className = jumlah > stok ? 'form-text text-danger' : 'form-text';
        } else {
            inputJumlah.removeAttribute('max');
            infoStok.textContent = '';
        }

        tampilTotal.textContent = 'Rp ' + (harga * jumlah).toLocaleString('id-ID');
    }

    pilihMenu.addEventListener('change', hitungTotal);
    inputJumlah.addEventListener('input', hitungTotal);
    hitungTotal();
</script>

<?php include '../includes/footer.php'; ?>
