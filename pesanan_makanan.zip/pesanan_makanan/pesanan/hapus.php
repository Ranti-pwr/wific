<?php
/**
 * File: pesanan/hapus.php
 * DELETE - Menghapus data pesanan berdasarkan ID.
 * Jika pesanan masih berstatus "Diproses", stok menu dikembalikan.
 */
require_once '../config/koneksi.php';

$id_pesanan = (int) ($_GET['id'] ?? 0);

// 1. Ambil data pesanan yang akan dihapus
$stmt = mysqli_prepare($koneksi, "SELECT id_menu, jumlah, status FROM pesanan WHERE id_pesanan = ?");
mysqli_stmt_bind_param($stmt, 'i', $id_pesanan);
mysqli_stmt_execute($stmt);
$pesanan = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$pesanan) {
    set_pesan('danger', 'Gagal menghapus: data pesanan tidak ditemukan.');
    arahkan_ke('index.php');
}

mysqli_begin_transaction($koneksi);
try {
    // 2. Kembalikan stok jika pesanan belum selesai (masih Diproses)
    //    - Selesai    : makanan sudah diberikan, stok tidak dikembalikan
    //    - Dibatalkan : stok sudah dikembalikan saat dibatalkan
    if ($pesanan['status'] === 'Diproses') {
        $stmt = mysqli_prepare($koneksi, "UPDATE menu SET stok = stok + ? WHERE id_menu = ?");
        mysqli_stmt_bind_param($stmt, 'ii', $pesanan['jumlah'], $pesanan['id_menu']);
        mysqli_stmt_execute($stmt);
    }

    // 3. Hapus pesanan
    $stmt = mysqli_prepare($koneksi, "DELETE FROM pesanan WHERE id_pesanan = ?");
    mysqli_stmt_bind_param($stmt, 'i', $id_pesanan);
    mysqli_stmt_execute($stmt);

    mysqli_commit($koneksi);
    set_pesan('success', 'Pesanan berhasil dihapus.');
} catch (Exception $e) {
    mysqli_rollback($koneksi);
    set_pesan('danger', 'Gagal menghapus pesanan: ' . $e->getMessage());
}

arahkan_ke('index.php');
