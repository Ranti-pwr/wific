<?php
/**
 * File: pesanan/index.php
 * READ - Menampilkan daftar pesanan (JOIN ke tabel menu agar nama menu tampil).
 */
require_once '../config/koneksi.php';
$judul_halaman = 'Data Pesanan';

$daftar_status = ['Diproses', 'Selesai', 'Dibatalkan'];

// Filter status dari URL (?status=...)
$filter_status = $_GET['status'] ?? '';

// Query dasar dengan JOIN: ambil data pesanan + nama menu dari tabel menu
$sql = "SELECT p.id_pesanan, p.nama_pelanggan, p.jumlah, p.total_harga, p.tanggal_pesan, p.status,
               m.nama_menu, m.harga
        FROM pesanan p
        JOIN menu m ON p.id_menu = m.id_menu";

if (in_array($filter_status, $daftar_status, true)) {
    $sql .= " WHERE p.status = ? ORDER BY p.tanggal_pesan DESC";
    $stmt = mysqli_prepare($koneksi, $sql);
    mysqli_stmt_bind_param($stmt, 's', $filter_status);
} else {
    $filter_status = '';
    $sql .= " ORDER BY p.tanggal_pesan DESC";
    $stmt = mysqli_prepare($koneksi, $sql);
}
mysqli_stmt_execute($stmt);
$hasil = mysqli_stmt_get_result($stmt);

include '../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1>Data Pesanan</h1>
        <p>Daftar seluruh pesanan pelanggan.</p>
    </div>
    <a id="btn-tambah-pesanan" href="tambah.php" class="btn btn-primer"><i class="bi bi-plus-lg me-1"></i> Buat Pesanan</a>
</div>

<div class="card card-app">
    <!-- Tombol filter status -->
    <div class="card-body border-bottom d-flex flex-wrap gap-2">
        <a href="index.php" class="btn btn-sm <?= $filter_status === '' ? 'btn-dark' : 'btn-light-app' ?>">Semua</a>
        <?php foreach ($daftar_status as $status): ?>
            <a href="index.php?status=<?= urlencode($status) ?>"
               class="btn btn-sm <?= $filter_status === $status ? 'btn-dark' : 'btn-light-app' ?>"><?= $status ?></a>
        <?php endforeach; ?>
    </div>

    <div class="table-responsive">
        <table class="table table-app">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Tanggal</th>
                    <th>Pelanggan</th>
                    <th>Menu</th>
                    <th>Harga</th>
                    <th>Jumlah</th>
                    <th>Total</th>
                    <th>Status</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php if (mysqli_num_rows($hasil) === 0): ?>
                <tr><td colspan="9" class="text-center teks-abu py-5">Belum ada data pesanan.</td></tr>
            <?php endif; ?>

            <?php $no = 1; while ($pesanan = mysqli_fetch_assoc($hasil)): ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td class="text-nowrap small"><?= date('d/m/Y H:i', strtotime($pesanan['tanggal_pesan'])) ?></td>
                    <td class="fw-medium"><?= htmlspecialchars($pesanan['nama_pelanggan']) ?></td>
                    <td><?= htmlspecialchars($pesanan['nama_menu']) ?></td>
                    <td class="text-nowrap"><?= rupiah($pesanan['harga']) ?></td>
                    <td><?= (int) $pesanan['jumlah'] ?></td>
                    <td class="text-nowrap fw-semibold"><?= rupiah($pesanan['total_harga']) ?></td>
                    <td><?= badge_status($pesanan['status']) ?></td>
                    <td class="text-center text-nowrap">
                        <a href="edit.php?id=<?= (int) $pesanan['id_pesanan'] ?>" class="btn btn-sm btn-outline-primary btn-aksi" title="Edit">
                            <i class="bi bi-pencil-square"></i>
                        </a>
                        <!-- Konfirmasi hapus dengan JavaScript confirm() -->
                        <a href="hapus.php?id=<?= (int) $pesanan['id_pesanan'] ?>" class="btn btn-sm btn-outline-danger btn-aksi" title="Hapus"
                           onclick="return confirm('Yakin ingin menghapus pesanan ini?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
