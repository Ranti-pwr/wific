<?php
/**
 * File: pesanan/edit.php
 * UPDATE - Mengubah jumlah dan status pesanan.
 * Stok menu ikut disesuaikan otomatis:
 *  - Jumlah ditambah  -> stok berkurang
 *  - Jumlah dikurangi -> stok bertambah
 *  - Status diubah ke "Dibatalkan" -> stok dikembalikan
 */
require_once '../config/koneksi.php';
$judul_halaman = 'Edit Pesanan';

$daftar_status = ['Diproses', 'Selesai', 'Dibatalkan'];
$daftar_error  = [];

// ---------------------------------------------------------
// 1. Ambil data pesanan berdasarkan ID (JOIN untuk info menu)
// ---------------------------------------------------------
$id_pesanan = (int) ($_GET['id'] ?? 0);

$sql = "SELECT p.*, m.nama_menu, m.harga, m.stok
        FROM pesanan p
        JOIN menu m ON p.id_menu = m.id_menu
        WHERE p.id_pesanan = ?";
$stmt = mysqli_prepare($koneksi, $sql);
mysqli_stmt_bind_param($stmt, 'i', $id_pesanan);
mysqli_stmt_execute($stmt);
$pesanan = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

if (!$pesanan) {
    set_pesan('danger', 'Data pesanan tidak ditemukan.');
    arahkan_ke('index.php');
}

$jumlah = (string) $pesanan['jumlah'];
$status = $pesanan['status'];

// ---------------------------------------------------------
// 2. PROSES FORM
// ---------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $jumlah = trim($_POST['jumlah'] ?? '');
    $status = trim($_POST['status'] ?? '');

    // Validasi
    if ($jumlah === '') {
        $daftar_error[] = 'Jumlah wajib diisi.';
    } elseif (!ctype_digit($jumlah) || (int) $jumlah <= 0) {
        $daftar_error[] = 'Jumlah harus berupa angka lebih dari 0.';
    }
    if (!in_array($status, $daftar_status, true)) {
        $daftar_error[] = 'Status wajib dipilih.';
    }

    if (empty($daftar_error)) {
        $jumlah_baru = (int) $jumlah;

        // Hitung berapa stok yang "terpakai" sebelum dan sesudah diedit.
        // Pesanan yang Dibatalkan dianggap tidak memakai stok.
        $pakai_lama = ($pesanan['status'] !== 'Dibatalkan') ? (int) $pesanan['jumlah'] : 0;
        $pakai_baru = ($status !== 'Dibatalkan') ? $jumlah_baru : 0;
        $selisih    = $pakai_baru - $pakai_lama;   // positif = stok berkurang, negatif = stok kembali

        // Validasi: jumlah tidak boleh melebihi stok yang tersedia
        if ($selisih > $pesanan['stok']) {
            $maksimal = $pesanan['stok'] + $pakai_lama;
            $daftar_error[] = 'Stok tidak mencukupi. Jumlah maksimal untuk pesanan ini adalah ' . $maksimal . '.';
        }
    }

    if (empty($daftar_error)) {
        // Total harga dihitung ulang: harga menu x jumlah baru
        $total_harga = $pesanan['harga'] * $jumlah_baru;
        $id_menu     = (int) $pesanan['id_menu'];

        mysqli_begin_transaction($koneksi);
        try {
            // a. Sesuaikan stok menu (hanya jika ada perubahan)
            if ($selisih !== 0) {
                $stmt = mysqli_prepare($koneksi, "UPDATE menu SET stok = stok - ? WHERE id_menu = ? AND stok >= ?");
                mysqli_stmt_bind_param($stmt, 'iii', $selisih, $id_menu, $selisih);
                mysqli_stmt_execute($stmt);
                if (mysqli_stmt_affected_rows($stmt) === 0) {
                    throw new Exception('Stok tidak mencukupi.');
                }
            }

            // b. Update data pesanan
            $stmt = mysqli_prepare($koneksi, "UPDATE pesanan SET jumlah = ?, total_harga = ?, status = ? WHERE id_pesanan = ?");
            mysqli_stmt_bind_param($stmt, 'iisi', $jumlah_baru, $total_harga, $status, $id_pesanan);
            mysqli_stmt_execute($stmt);

            mysqli_commit($koneksi);
            set_pesan('success', 'Pesanan atas nama "' . $pesanan['nama_pelanggan'] . '" berhasil diperbarui.');
            arahkan_ke('index.php');
        } catch (Exception $e) {
            mysqli_rollback($koneksi);
            $daftar_error[] = 'Gagal memperbarui pesanan: ' . $e->getMessage();
        }
    }
}

include '../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1>Edit Pesanan</h1>
        <p>Ubah jumlah dan status pesanan.</p>
    </div>
    <a href="index.php" class="btn btn-light-app"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
</div>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card card-app">
            <div class="card-body p-4">

                <?php if (!empty($daftar_error)): ?>
                    <div class="alert alert-danger alert-app">
                        <strong><i class="bi bi-exclamation-triangle-fill me-1"></i> Data belum valid:</strong>
                        <ul class="mb-0 mt-1">
                            <?php foreach ($daftar_error as $error): ?>
                                <li><?= htmlspecialchars($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- Informasi pesanan (tidak bisa diubah) -->
                <div class="row g-3 mb-4">
                    <div class="col-sm-6">
                        <small class="teks-abu d-block">Pelanggan</small>
                        <strong><?= htmlspecialchars($pesanan['nama_pelanggan']) ?></strong>
                    </div>
                    <div class="col-sm-6">
                        <small class="teks-abu d-block">Menu</small>
                        <strong><?= htmlspecialchars($pesanan['nama_menu']) ?></strong>
                        <span class="teks-abu">(<?= rupiah($pesanan['harga']) ?>)</span>
                    </div>
                    <div class="col-sm-6">
                        <small class="teks-abu d-block">Tanggal Pesan</small>
                        <strong><?= date('d/m/Y H:i', strtotime($pesanan['tanggal_pesan'])) ?></strong>
                    </div>
                    <div class="col-sm-6">
                        <small class="teks-abu d-block">Sisa Stok Menu</small>
                        <strong><?= (int) $pesanan['stok'] ?></strong>
                    </div>
                </div>

                <form method="post" id="form-edit-pesanan">
                    <div class="row">
                        <div class="col-sm-6 mb-3">
                            <label for="jumlah" class="form-label">Jumlah</label>
                            <input type="number" id="jumlah" name="jumlah" class="form-control" min="1"
                                   value="<?= htmlspecialchars($jumlah) ?>" required>
                        </div>
                        <div class="col-sm-6 mb-3">
                            <label for="status" class="form-label">Status</label>
                            <select id="status" name="status" class="form-select" required>
                                <?php foreach ($daftar_status as $pilihan): ?>
                                    <option value="<?= $pilihan ?>" <?= $status === $pilihan ? 'selected' : '' ?>><?= $pilihan ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>

                    <div class="p-3 rounded-3 mb-3 d-flex justify-content-between align-items-center" style="background:#fff7f3">
                        <span class="teks-abu">Total Harga</span>
                        <strong id="tampil-total" class="fs-5" style="color:var(--primer)"><?= rupiah($pesanan['total_harga']) ?></strong>
                    </div>

                    <div class="d-flex gap-2 justify-content-end">
                        <a href="index.php" class="btn btn-light-app">Batal</a>
                        <button id="btn-update-pesanan" type="submit" class="btn btn-primer"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

<script>
    // Perbarui tampilan total harga saat jumlah diubah
    const hargaMenu   = <?= (int) $pesanan['harga'] ?>;
    const inputJumlah = document.getElementById('jumlah');
    const tampilTotal = document.getElementById('tampil-total');

    inputJumlah.addEventListener('input', function () {
        const jumlah = parseInt(inputJumlah.value) || 0;
        tampilTotal.textContent = 'Rp ' + (hargaMenu * jumlah).toLocaleString('id-ID');
    });
</script>

<?php include '../includes/footer.php'; ?>
