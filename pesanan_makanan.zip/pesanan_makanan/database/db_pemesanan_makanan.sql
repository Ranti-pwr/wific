-- =====================================================
-- Database : db_pemesanan_makanan
-- Aplikasi : CRUD Pemesanan Makanan (PHP Native)
-- =====================================================

-- 1. Buat database (jika belum ada) lalu gunakan
CREATE DATABASE IF NOT EXISTS db_pemesanan_makanan
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_general_ci;

USE db_pemesanan_makanan;

-- 2. Hapus tabel lama (urutan penting: tabel anak dulu, baru tabel induk)
DROP TABLE IF EXISTS pesanan;
DROP TABLE IF EXISTS menu;

-- 3. Tabel MENU (tabel induk)
CREATE TABLE menu (
    id_menu   INT          NOT NULL AUTO_INCREMENT,
    nama_menu VARCHAR(100) NOT NULL,
    kategori  VARCHAR(50)  NOT NULL,
    harga     INT          NOT NULL,
    stok      INT          NOT NULL DEFAULT 0,
    PRIMARY KEY (id_menu)
) ENGINE=InnoDB;

-- 4. Tabel PESANAN (tabel anak, berelasi ke tabel menu)
CREATE TABLE pesanan (
    id_pesanan     INT          NOT NULL AUTO_INCREMENT,
    id_menu        INT          NOT NULL,
    nama_pelanggan VARCHAR(100) NOT NULL,
    jumlah         INT          NOT NULL,
    total_harga    INT          NOT NULL,
    tanggal_pesan  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status         ENUM('Diproses','Selesai','Dibatalkan') NOT NULL DEFAULT 'Diproses',
    PRIMARY KEY (id_pesanan),
    -- Relasi: pesanan.id_menu -> menu.id_menu
    -- ON DELETE RESTRICT : menu tidak bisa dihapus jika masih dipakai di pesanan
    -- ON UPDATE CASCADE  : jika id_menu berubah, id di pesanan ikut berubah
    CONSTRAINT fk_pesanan_menu
        FOREIGN KEY (id_menu) REFERENCES menu (id_menu)
        ON DELETE RESTRICT
        ON UPDATE CASCADE
) ENGINE=InnoDB;

-- 5. Data dummy untuk tabel menu
INSERT INTO menu (nama_menu, kategori, harga, stok) VALUES
('Nasi Goreng Spesial',   'Makanan', 25000, 20),
('Mie Ayam Bakso',        'Makanan', 20000, 15),
('Ayam Geprek Sambal Ijo','Makanan', 22000, 18),
('Sate Ayam (10 tusuk)',  'Makanan', 30000,  4),
('Es Teh Manis',          'Minuman',  5000, 50),
('Es Jeruk Peras',        'Minuman',  8000, 40),
('Kopi Susu Gula Aren',   'Minuman', 18000, 25),
('Pisang Goreng Keju',    'Camilan', 15000,  3);

-- 6. Data dummy untuk tabel pesanan
INSERT INTO pesanan (id_menu, nama_pelanggan, jumlah, total_harga, tanggal_pesan, status) VALUES
(1, 'Budi Santoso',  2, 50000, '2026-10-15 11:20:00', 'Selesai'),
(5, 'Budi Santoso',  2, 10000, '2026-10-15 11:21:00', 'Selesai'),
(3, 'Siti Aminah',   1, 22000, '2026-10-15 12:05:00', 'Selesai'),
(7, 'Andi Wijaya',   3, 54000, '2026-10-16 09:15:00', 'Diproses'),
(2, 'Dewi Lestari',  1, 20000, '2026-10-16 10:02:00', 'Dibatalkan'),
(8, 'Rina Kartika',  2, 30000, '2026-10-16 11:45:00', 'Diproses');
