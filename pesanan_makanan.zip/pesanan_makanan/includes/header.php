<?php
/**
 * File: includes/header.php
 * Bagian atas halaman: <head>, CSS, dan navbar.
 * Sebelum meng-include file ini, set variabel $judul_halaman di halaman masing-masing.
 */

$judul_halaman = $judul_halaman ?? 'Beranda';

// Menentukan menu navbar yang sedang aktif berdasarkan alamat halaman
$halaman_sekarang = $_SERVER['PHP_SELF'];
$aktif_menu       = strpos($halaman_sekarang, '/menu/') !== false;
$aktif_pesanan    = strpos($halaman_sekarang, '/pesanan/') !== false;
$aktif_beranda    = !$aktif_menu && !$aktif_pesanan;
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Aplikasi CRUD Pemesanan Makanan sederhana dengan PHP Native dan MySQL.">
    <title><?= htmlspecialchars($judul_halaman) ?> | Pemesanan Makanan</title>

    <!-- Bootstrap 5, Bootstrap Icons & Google Font (via CDN) -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- CSS tambahan agar tampilan lebih menarik -->
    <style>
        :root {
            --primer: #ff6b35;
            --primer-2: #f7418f;
            --gelap: #1e2235;
            --abu: #6b7280;
            --latar: #f5f6fa;
            --radius: 16px;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background: var(--latar);
            color: var(--gelap);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }
        main { flex: 1; }

        /* ---------- Navbar ---------- */
        .navbar-app {
            background: linear-gradient(135deg, var(--primer), var(--primer-2));
            box-shadow: 0 8px 24px rgba(247, 65, 143, .25);
        }
        .navbar-app .navbar-brand { color: #fff; font-weight: 700; letter-spacing: .3px; }
        .navbar-app .nav-link {
            color: rgba(255, 255, 255, .85);
            font-weight: 500;
            border-radius: 10px;
            padding: .5rem 1rem !important;
            transition: all .2s;
        }
        .navbar-app .nav-link:hover,
        .navbar-app .nav-link.active { color: #fff; background: rgba(255, 255, 255, .2); }
        .navbar-app .navbar-toggler { border-color: rgba(255,255,255,.5); }
        .navbar-app .navbar-toggler-icon { filter: invert(1); }

        /* ---------- Judul halaman ---------- */
        .page-header {
            display: flex; flex-wrap: wrap; gap: 1rem;
            align-items: center; justify-content: space-between;
            margin-bottom: 1.5rem;
        }
        .page-header h1 { font-size: 1.6rem; font-weight: 700; margin: 0; }
        .page-header p  { color: var(--abu); margin: 0; }

        /* ---------- Kartu ---------- */
        .card-app {
            border: none;
            border-radius: var(--radius);
            box-shadow: 0 4px 20px rgba(30, 34, 53, .06);
            animation: muncul .45s ease both;
        }
        @keyframes muncul {
            from { opacity: 0; transform: translateY(12px); }
            to   { opacity: 1; transform: none; }
        }

        /* ---------- Tombol ---------- */
        .btn-primer {
            background: linear-gradient(135deg, var(--primer), var(--primer-2));
            border: none; color: #fff; font-weight: 500;
            border-radius: 10px; padding: .55rem 1.1rem;
            transition: all .2s;
        }
        .btn-primer:hover { color: #fff; transform: translateY(-2px); box-shadow: 0 6px 16px rgba(247, 65, 143, .35); }
        .btn-light-app { background: #fff; border: 1px solid #e3e6ee; border-radius: 10px; padding: .55rem 1.1rem; }
        .btn-aksi { border-radius: 8px; padding: .3rem .6rem; transition: transform .15s; }
        .btn-aksi:hover { transform: scale(1.08); }

        /* ---------- Tabel ---------- */
        .table-app { margin: 0; }
        .table-app thead th {
            background: #fafbff; color: var(--abu);
            font-size: .75rem; text-transform: uppercase; letter-spacing: .05em; font-weight: 600;
            border-bottom: 1px solid #eef0f5; padding: .9rem 1rem; white-space: nowrap;
        }
        .table-app td { padding: .85rem 1rem; vertical-align: middle; border-color: #f1f2f6; }
        .table-app tbody tr { transition: background .15s; }
        .table-app tbody tr:hover { background: #fff7f3; }

        /* ---------- Badge lembut ---------- */
        .badge-soft { display: inline-block; padding: .35em .8em; border-radius: 999px; font-size: .78rem; font-weight: 600; }
        .badge-soft-warning   { background: #fff4e0; color: #c77700; }
        .badge-soft-success   { background: #e3f8ec; color: #18864b; }
        .badge-soft-danger    { background: #fde7ea; color: #c9283e; }
        .badge-soft-info      { background: #e6f0ff; color: #2b5fd9; }
        .badge-soft-secondary { background: #eef0f5; color: #555c6e; }

        /* ---------- Form ---------- */
        .form-label { font-weight: 500; font-size: .9rem; }
        .form-control, .form-select { border-radius: 10px; padding: .65rem .9rem; border-color: #e3e6ee; }
        .form-control:focus, .form-select:focus { border-color: var(--primer); box-shadow: 0 0 0 .2rem rgba(255, 107, 53, .15); }

        /* ---------- Alert ---------- */
        .alert-app { border: none; border-radius: 12px; box-shadow: 0 4px 14px rgba(0,0,0,.05); animation: muncul .35s ease both; }

        /* ---------- Dashboard ---------- */
        .hero {
            background: radial-gradient(circle at 85% 20%, rgba(247,65,143,.55), transparent 45%),
                        linear-gradient(135deg, #1e2235, #33284d);
            color: #fff; border-radius: 20px; padding: 2.2rem; position: relative; overflow: hidden;
        }
        .hero h1 { font-weight: 700; font-size: 1.9rem; }
        .hero p  { color: rgba(255,255,255,.75); max-width: 520px; }
        .hero .emoji { position: absolute; right: 2rem; bottom: -1rem; font-size: 7rem; opacity: .9; transform: rotate(-12deg); }
        .stat-card { padding: 1.3rem; display: flex; align-items: center; gap: 1rem; transition: transform .2s; }
        .stat-card:hover { transform: translateY(-4px); }
        .stat-ikon {
            width: 52px; height: 52px; border-radius: 14px;
            display: grid; place-items: center; font-size: 1.4rem; flex-shrink: 0;
        }
        .stat-card small { color: var(--abu); }
        .stat-card h3 { font-size: 1.35rem; font-weight: 700; margin: 0; }

        .teks-abu { color: var(--abu); }
        footer { color: var(--abu); font-size: .85rem; }

        @media (max-width: 576px) {
            .hero { padding: 1.5rem; }
            .hero .emoji { font-size: 4.5rem; right: 1rem; }
            .page-header h1 { font-size: 1.35rem; }
        }
    </style>
</head>
<body>

<!-- ============ NAVBAR ============ -->
<nav class="navbar navbar-expand-lg navbar-app sticky-top">
    <div class="container">
        <a class="navbar-brand" href="<?= BASE_URL ?>/index.php">
            <i class="bi bi-egg-fried me-1"></i> Warung Kita
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navUtama"
                aria-controls="navUtama" aria-expanded="false" aria-label="Buka navigasi">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navUtama">
            <ul class="navbar-nav ms-auto gap-1 mt-2 mt-lg-0">
                <li class="nav-item">
                    <a id="nav-beranda" class="nav-link <?= $aktif_beranda ? 'active' : '' ?>" href="<?= BASE_URL ?>/index.php">
                        <i class="bi bi-house-door me-1"></i> Beranda
                    </a>
                </li>
                <li class="nav-item">
                    <a id="nav-menu" class="nav-link <?= $aktif_menu ? 'active' : '' ?>" href="<?= BASE_URL ?>/menu/index.php">
                        <i class="bi bi-journal-text me-1"></i> Data Menu
                    </a>
                </li>
                <li class="nav-item">
                    <a id="nav-pesanan" class="nav-link <?= $aktif_pesanan ? 'active' : '' ?>" href="<?= BASE_URL ?>/pesanan/index.php">
                        <i class="bi bi-receipt me-1"></i> Data Pesanan
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<!-- ============ ISI HALAMAN ============ -->
<main class="container py-4">
    <?php tampil_pesan(); // tampilkan pesan sukses/gagal jika ada ?>
