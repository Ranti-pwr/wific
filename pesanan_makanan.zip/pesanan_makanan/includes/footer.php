<?php
/**
 * File: includes/footer.php
 * Bagian bawah halaman: penutup <main>, footer, dan JavaScript.
 */
?>
</main>

<!-- ============ FOOTER ============ -->
<footer class="text-center py-4">
    &copy; <?= date('Y') ?> Warung Kita &middot; Aplikasi Pemesanan Makanan (PHP Native + MySQL)
</footer>

<!-- JavaScript Bootstrap (untuk navbar mobile & tombol tutup alert) -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
