<?php
/**
 * File: menu/index.php
 * READ - Menampilkan daftar menu (dengan fitur pencarian).
 */
require_once '../config/koneksi.php';
$judul_halaman = 'Data Menu';

// Ambil kata kunci pencarian dari URL (?cari=...)
$kata_kunci = trim($_GET['cari'] ?? '');

if ($kata_kunci !== '') {
    // Pencarian memakai prepared statement agar aman dari SQL Injection
    $sql  = "SELECT * FROM menu WHERE nama_menu LIKE ? OR kategori LIKE ? ORDER BY kategori, nama_menu";
    $stmt = mysqli_prepare($koneksi, $sql);
    $pola = '%' . $kata_kunci . '%';
    mysqli_stmt_bind_param($stmt, 'ss', $pola, $pola);
} else {
    $stmt = mysqli_prepare($koneksi, "SELECT * FROM menu ORDER BY kategori, nama_menu");
}
mysqli_stmt_execute($stmt);
$hasil = mysqli_stmt_get_result($stmt);

include '../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1>Data Menu</h1>
        <p>Daftar makanan & minuman yang tersedia.</p>
    </div>
    <a id="btn-tambah-menu" href="tambah.php" class="btn btn-primer"><i class="bi bi-plus-lg me-1"></i> Tambah Menu</a>
</div>

<div class="card card-app">
    <!-- Form pencarian -->
    <div class="card-body border-bottom">
        <form method="get" class="d-flex gap-2" role="search">
            <input id="input-cari-menu" type="text" name="cari" class="form-control" placeholder="Cari nama menu atau kategori..."
                   value="<?= htmlspecialchars($kata_kunci) ?>">
            <button id="btn-cari-menu" class="btn btn-light-app" type="submit"><i class="bi bi-search"></i></button>
            <?php if ($kata_kunci !== ''): ?>
                <a href="index.php" class="btn btn-light-app" title="Reset"><i class="bi bi-x-lg"></i></a>
            <?php endif; ?>
        </form>
    </div>

    <div class="table-responsive">
        <table class="table table-app">
            <thead>
                <tr>
                    <th>No</th>
                    <th>Nama Menu</th>
                    <th>Kategori</th>
                    <th>Harga</th>
                    <th>Stok</th>
                    <th class="text-center">Aksi</th>
                </tr>
            </thead>
            <tbody>
            <?php if (mysqli_num_rows($hasil) === 0): ?>
                <tr><td colspan="6" class="text-center teks-abu py-5">Data menu tidak ditemukan.</td></tr>
            <?php endif; ?>

            <?php $no = 1; while ($menu = mysqli_fetch_assoc($hasil)): ?>
                <?php
                // Tentukan warna badge stok: habis = merah, sedikit = kuning, aman = hijau
                if ($menu['stok'] == 0)      { $kelas_stok = 'badge-soft-danger'; }
                elseif ($menu['stok'] <= 5)  { $kelas_stok = 'badge-soft-warning'; }
                else                         { $kelas_stok = 'badge-soft-success'; }
                ?>
                <tr>
                    <td><?= $no++ ?></td>
                    <td class="fw-medium"><?= htmlspecialchars($menu['nama_menu']) ?></td>
                    <td><span class="badge-soft badge-soft-info"><?= htmlspecialchars($menu['kategori']) ?></span></td>
                    <td><?= rupiah($menu['harga']) ?></td>
                    <td><span class="badge-soft <?= $kelas_stok ?>"><?= (int) $menu['stok'] ?></span></td>
                    <td class="text-center text-nowrap">
                        <a href="edit.php?id=<?= (int) $menu['id_menu'] ?>" class="btn btn-sm btn-outline-primary btn-aksi" title="Edit">
                            <i class="bi bi-pencil-square"></i>
                        </a>
                        <!-- Konfirmasi hapus dengan JavaScript confirm() -->
                        <a href="hapus.php?id=<?= (int) $menu['id_menu'] ?>" class="btn btn-sm btn-outline-danger btn-aksi" title="Hapus"
                           onclick="return confirm('Yakin ingin menghapus menu ini?')">
                            <i class="bi bi-trash"></i>
                        </a>
                    </td>
                </tr>
            <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
