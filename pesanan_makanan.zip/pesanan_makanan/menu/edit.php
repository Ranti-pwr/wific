<?php
/**
 * File: menu/edit.php
 * UPDATE - Mengubah data menu yang sudah ada.
 */
require_once '../config/koneksi.php';
$judul_halaman = 'Edit Menu';

$daftar_kategori = ['Makanan', 'Minuman', 'Camilan'];
$daftar_error    = [];

// ---------------------------------------------------------
// 1. Ambil ID dari URL (edit.php?id=...) lalu cari datanya
// ---------------------------------------------------------
$id_menu = (int) ($_GET['id'] ?? 0);

$stmt = mysqli_prepare($koneksi, "SELECT * FROM menu WHERE id_menu = ?");
mysqli_stmt_bind_param($stmt, 'i', $id_menu);
mysqli_stmt_execute($stmt);
$menu = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt));

// Jika data tidak ditemukan, kembali ke daftar menu
if (!$menu) {
    set_pesan('danger', 'Data menu tidak ditemukan.');
    arahkan_ke('index.php');
}

// Isi awal form diambil dari database
$nama_menu = $menu['nama_menu'];
$kategori  = $menu['kategori'];
$harga     = (string) $menu['harga'];
$stok      = (string) $menu['stok'];

// ---------------------------------------------------------
// 2. PROSES FORM saat tombol Simpan ditekan
// ---------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nama_menu = trim($_POST['nama_menu'] ?? '');
    $kategori  = trim($_POST['kategori'] ?? '');
    $harga     = trim($_POST['harga'] ?? '');
    $stok      = trim($_POST['stok'] ?? '');

    // Validasi input
    if ($nama_menu === '') {
        $daftar_error[] = 'Nama menu wajib diisi.';
    }
    if (!in_array($kategori, $daftar_kategori, true)) {
        $daftar_error[] = 'Kategori wajib dipilih.';
    }
    if ($harga === '') {
        $daftar_error[] = 'Harga wajib diisi.';
    } elseif (!ctype_digit($harga) || (int) $harga <= 0) {
        $daftar_error[] = 'Harga harus berupa angka lebih dari 0.';
    }
    if ($stok === '') {
        $daftar_error[] = 'Stok wajib diisi.';
    } elseif (!ctype_digit($stok)) {
        $daftar_error[] = 'Stok harus berupa angka 0 atau lebih.';
    }

    // Jika valid, update data di database
    if (empty($daftar_error)) {
        $sql  = "UPDATE menu SET nama_menu = ?, kategori = ?, harga = ?, stok = ? WHERE id_menu = ?";
        $stmt = mysqli_prepare($koneksi, $sql);
        $harga_angka = (int) $harga;
        $stok_angka  = (int) $stok;
        mysqli_stmt_bind_param($stmt, 'ssiii', $nama_menu, $kategori, $harga_angka, $stok_angka, $id_menu);

        if (mysqli_stmt_execute($stmt)) {
            set_pesan('success', 'Menu "' . $nama_menu . '" berhasil diperbarui.');
        } else {
            set_pesan('danger', 'Gagal memperbarui menu.');
        }
        arahkan_ke('index.php');
    }
}

include '../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1>Edit Menu</h1>
        <p>Ubah data menu <strong><?= htmlspecialchars($menu['nama_menu']) ?></strong>.</p>
    </div>
    <a href="index.php" class="btn btn-light-app"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
</div>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card card-app">
            <div class="card-body p-4">

                <?php if (!empty($daftar_error)): ?>
                    <div class="alert alert-danger alert-app">
                        <strong><i class="bi bi-exclamation-triangle-fill me-1"></i> Data belum valid:</strong>
                        <ul class="mb-0 mt-1">
                            <?php foreach ($daftar_error as $error): ?>
                                <li><?= htmlspecialchars($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="post" id="form-edit-menu">
                    <div class="mb-3">
                        <label for="nama_menu" class="form-label">Nama Menu</label>
                        <input type="text" id="nama_menu" name="nama_menu" class="form-control" maxlength="100"
                               value="<?= htmlspecialchars($nama_menu) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="kategori" class="form-label">Kategori</label>
                        <select id="kategori" name="kategori" class="form-select" required>
                            <option value="">-- Pilih Kategori --</option>
                            <?php foreach ($daftar_kategori as $pilihan): ?>
                                <option value="<?= $pilihan ?>" <?= $kategori === $pilihan ? 'selected' : '' ?>><?= $pilihan ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 mb-3">
                            <label for="harga" class="form-label">Harga (Rp)</label>
                            <input type="number" id="harga" name="harga" class="form-control" min="1"
                                   value="<?= htmlspecialchars($harga) ?>" required>
                        </div>
                        <div class="col-sm-6 mb-3">
                            <label for="stok" class="form-label">Stok</label>
                            <input type="number" id="stok" name="stok" class="form-control" min="0"
                                   value="<?= htmlspecialchars($stok) ?>" required>
                        </div>
                    </div>
                    <div class="d-flex gap-2 justify-content-end mt-2">
                        <a href="index.php" class="btn btn-light-app">Batal</a>
                        <button id="btn-update-menu" type="submit" class="btn btn-primer"><i class="bi bi-save me-1"></i> Simpan Perubahan</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
