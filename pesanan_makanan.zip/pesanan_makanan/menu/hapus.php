<?php
/**
 * File: menu/hapus.php
 * DELETE - Menghapus data menu berdasarkan ID.
 * Tidak menampilkan halaman, langsung kembali ke menu/index.php.
 */
require_once '../config/koneksi.php';

$id_menu = (int) ($_GET['id'] ?? 0);

// 1. Cek apakah menu masih dipakai di tabel pesanan
//    (karena ada FOREIGN KEY, menu yang masih dipakai tidak boleh dihapus)
$stmt = mysqli_prepare($koneksi, "SELECT COUNT(*) AS jumlah FROM pesanan WHERE id_menu = ?");
mysqli_stmt_bind_param($stmt, 'i', $id_menu);
mysqli_stmt_execute($stmt);
$jumlah_dipakai = mysqli_fetch_assoc(mysqli_stmt_get_result($stmt))['jumlah'];

if ($jumlah_dipakai > 0) {
    set_pesan('warning', 'Menu tidak bisa dihapus karena masih digunakan pada ' . $jumlah_dipakai . ' pesanan.');
    arahkan_ke('index.php');
}

// 2. Hapus menu
$stmt = mysqli_prepare($koneksi, "DELETE FROM menu WHERE id_menu = ?");
mysqli_stmt_bind_param($stmt, 'i', $id_menu);
mysqli_stmt_execute($stmt);

// 3. Cek apakah ada baris yang benar-benar terhapus
if (mysqli_stmt_affected_rows($stmt) > 0) {
    set_pesan('success', 'Menu berhasil dihapus.');
} else {
    set_pesan('danger', 'Gagal menghapus: data menu tidak ditemukan.');
}
arahkan_ke('index.php');
