<?php
/**
 * File: menu/tambah.php
 * CREATE - Menambahkan data menu baru.
 */
require_once '../config/koneksi.php';
$judul_halaman = 'Tambah Menu';

// Pilihan kategori yang tersedia
$daftar_kategori = ['Makanan', 'Minuman', 'Camilan'];

// Variabel untuk menampung input & pesan error (agar input tidak hilang saat gagal)
$nama_menu = $kategori = $harga = $stok = '';
$daftar_error = [];

// ---------------------------------------------------------
// PROSES FORM: dijalankan hanya ketika tombol Simpan ditekan (method POST)
// ---------------------------------------------------------
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // 1. Ambil data dari form & hapus spasi di awal/akhir
    $nama_menu = trim($_POST['nama_menu'] ?? '');
    $kategori  = trim($_POST['kategori'] ?? '');
    $harga     = trim($_POST['harga'] ?? '');
    $stok      = trim($_POST['stok'] ?? '');

    // 2. Validasi: tidak boleh kosong & harus angka yang benar
    if ($nama_menu === '') {
        $daftar_error[] = 'Nama menu wajib diisi.';
    }
    if (!in_array($kategori, $daftar_kategori, true)) {
        $daftar_error[] = 'Kategori wajib dipilih.';
    }
    if ($harga === '') {
        $daftar_error[] = 'Harga wajib diisi.';
    } elseif (!ctype_digit($harga) || (int) $harga <= 0) {
        $daftar_error[] = 'Harga harus berupa angka lebih dari 0.';
    }
    if ($stok === '') {
        $daftar_error[] = 'Stok wajib diisi.';
    } elseif (!ctype_digit($stok)) {
        $daftar_error[] = 'Stok harus berupa angka 0 atau lebih.';
    }

    // 3. Jika tidak ada error, simpan ke database
    if (empty($daftar_error)) {
        $sql  = "INSERT INTO menu (nama_menu, kategori, harga, stok) VALUES (?, ?, ?, ?)";
        $stmt = mysqli_prepare($koneksi, $sql);
        $harga_angka = (int) $harga;
        $stok_angka  = (int) $stok;
        // 's' = string, 'i' = integer
        mysqli_stmt_bind_param($stmt, 'ssii', $nama_menu, $kategori, $harga_angka, $stok_angka);

        if (mysqli_stmt_execute($stmt)) {
            set_pesan('success', 'Menu "' . $nama_menu . '" berhasil ditambahkan.');
        } else {
            set_pesan('danger', 'Gagal menambahkan menu.');
        }
        arahkan_ke('index.php');
    }
}

include '../includes/header.php';
?>

<div class="page-header">
    <div>
        <h1>Tambah Menu</h1>
        <p>Isi data menu baru di bawah ini.</p>
    </div>
    <a href="index.php" class="btn btn-light-app"><i class="bi bi-arrow-left me-1"></i> Kembali</a>
</div>

<div class="row justify-content-center">
    <div class="col-lg-7">
        <div class="card card-app">
            <div class="card-body p-4">

                <!-- Tampilkan daftar error validasi (jika ada) -->
                <?php if (!empty($daftar_error)): ?>
                    <div class="alert alert-danger alert-app">
                        <strong><i class="bi bi-exclamation-triangle-fill me-1"></i> Data belum valid:</strong>
                        <ul class="mb-0 mt-1">
                            <?php foreach ($daftar_error as $error): ?>
                                <li><?= htmlspecialchars($error) ?></li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <form method="post" id="form-tambah-menu">
                    <div class="mb-3">
                        <label for="nama_menu" class="form-label">Nama Menu</label>
                        <input type="text" id="nama_menu" name="nama_menu" class="form-control" maxlength="100"
                               placeholder="Contoh: Nasi Goreng Spesial" value="<?= htmlspecialchars($nama_menu) ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="kategori" class="form-label">Kategori</label>
                        <select id="kategori" name="kategori" class="form-select" required>
                            <option value="">-- Pilih Kategori --</option>
                            <?php foreach ($daftar_kategori as $pilihan): ?>
                                <option value="<?= $pilihan ?>" <?= $kategori === $pilihan ? 'selected' : '' ?>><?= $pilihan ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-sm-6 mb-3">
                            <label for="harga" class="form-label">Harga (Rp)</label>
                            <input type="number" id="harga" name="harga" class="form-control" min="1"
                                   placeholder="25000" value="<?= htmlspecialchars($harga) ?>" required>
                        </div>
                        <div class="col-sm-6 mb-3">
                            <label for="stok" class="form-label">Stok</label>
                            <input type="number" id="stok" name="stok" class="form-control" min="0"
                                   placeholder="10" value="<?= htmlspecialchars($stok) ?>" required>
                        </div>
                    </div>
                    <div class="d-flex gap-2 justify-content-end mt-2">
                        <a href="index.php" class="btn btn-light-app">Batal</a>
                        <button id="btn-simpan-menu" type="submit" class="btn btn-primer"><i class="bi bi-save me-1"></i> Simpan</button>
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>

<?php include '../includes/footer.php'; ?>
