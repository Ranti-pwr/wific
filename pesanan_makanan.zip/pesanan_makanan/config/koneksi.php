<?php
/**
 * File: config/koneksi.php
 * Berisi pengaturan koneksi database dan fungsi-fungsi bantu
 * yang dipakai di semua halaman.
 */

// Mulai session (dipakai untuk menyimpan pesan sukses/gagal antar halaman)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// ---------------------------------------------------------
// 1. PENGATURAN DATABASE (sesuaikan jika berbeda)
// ---------------------------------------------------------
$db_host = 'localhost';
$db_user = 'root';
$db_pass = '';                       // XAMPP/Laragon default: kosong
$db_name = 'db_pemesanan_makanan';

// Alamat dasar aplikasi (sesuaikan dengan nama folder di htdocs / www)
// Contoh: http://localhost/pesanan_makanan  ->  '/pesanan_makanan'
define('BASE_URL', '/pesanan_makanan');

// ---------------------------------------------------------
// 2. MEMBUAT KONEKSI (MySQLi prosedural)
// ---------------------------------------------------------
// Aktifkan mode exception agar error database mudah ditangkap dengan try-catch
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

try {
    $koneksi = mysqli_connect($db_host, $db_user, $db_pass, $db_name);
    mysqli_set_charset($koneksi, 'utf8mb4');
} catch (mysqli_sql_exception $e) {
    die('<h3 style="font-family:sans-serif;color:#c0392b">Koneksi database gagal: '
        . htmlspecialchars($e->getMessage()) . '</h3>');
}

// ---------------------------------------------------------
// 3. FUNGSI-FUNGSI BANTU
// ---------------------------------------------------------

/**
 * Menyimpan pesan notifikasi ke session.
 * $tipe: 'success' (hijau), 'danger' (merah), 'warning' (kuning)
 */
function set_pesan($tipe, $isi)
{
    $_SESSION['pesan'] = ['tipe' => $tipe, 'isi' => $isi];
}

/**
 * Menampilkan pesan notifikasi (jika ada) lalu menghapusnya dari session,
 * sehingga pesan hanya muncul satu kali.
 */
function tampil_pesan()
{
    if (!empty($_SESSION['pesan'])) {
        $tipe = $_SESSION['pesan']['tipe'];
        $isi  = $_SESSION['pesan']['isi'];
        $ikon = ($tipe === 'success') ? 'bi-check-circle-fill' : 'bi-exclamation-triangle-fill';

        echo '<div class="alert alert-' . htmlspecialchars($tipe) . ' alert-dismissible fade show alert-app" role="alert">';
        echo '<i class="bi ' . $ikon . ' me-2"></i>' . htmlspecialchars($isi);
        echo '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Tutup"></button>';
        echo '</div>';

        unset($_SESSION['pesan']);
    }
}

/**
 * Mengubah angka menjadi format Rupiah. Contoh: 25000 -> Rp 25.000
 */
function rupiah($angka)
{
    return 'Rp ' . number_format((int) $angka, 0, ',', '.');
}

/**
 * Menghasilkan badge (label berwarna) sesuai status pesanan.
 */
function badge_status($status)
{
    $warna = [
        'Diproses'   => 'badge-soft-warning',
        'Selesai'    => 'badge-soft-success',
        'Dibatalkan' => 'badge-soft-danger',
    ];
    $kelas = $warna[$status] ?? 'badge-soft-secondary';
    return '<span class="badge-soft ' . $kelas . '">' . htmlspecialchars($status) . '</span>';
}

/**
 * Mengalihkan (redirect) ke halaman lain lalu menghentikan script.
 */
function arahkan_ke($url)
{
    header('Location: ' . $url);
    exit;
}
