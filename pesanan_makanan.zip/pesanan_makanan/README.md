# 🍜 Aplikasi CRUD Pemesanan Makanan (PHP Native + MySQL)

Aplikasi sederhana untuk mengelola **data menu** dan **data pesanan** makanan.
Dibuat dengan PHP Native (prosedural, MySQLi + prepared statement), MySQL, dan Bootstrap 5.

## 📁 Struktur Folder

```
pesanan_makanan/
├── config/koneksi.php          → koneksi database + fungsi bantu
├── includes/header.php         → <head>, CSS, navbar
├── includes/footer.php         → footer + JavaScript Bootstrap
├── menu/index.php              → daftar menu (Read + cari)
├── menu/tambah.php             → tambah menu (Create)
├── menu/edit.php               → ubah menu (Update)
├── menu/hapus.php              → hapus menu (Delete)
├── pesanan/index.php           → daftar pesanan + JOIN menu (Read)
├── pesanan/tambah.php          → buat pesanan (Create)
├── pesanan/edit.php            → ubah jumlah & status (Update)
├── pesanan/hapus.php           → hapus pesanan (Delete)
├── database/db_pemesanan_makanan.sql
└── index.php                   → dashboard / beranda
```

## ⚙️ Cara Instalasi

### XAMPP
1. Salin folder `pesanan_makanan` ke `C:\xampp\htdocs\`.
2. Buka **XAMPP Control Panel** → klik **Start** pada **Apache** dan **MySQL**.
3. Buka `http://localhost/phpmyadmin` → tab **Import** → pilih file
   `database/db_pemesanan_makanan.sql` → klik **Go/Import**.
4. Buka `http://localhost/pesanan_makanan` di browser.

### Laragon
1. Salin folder ke `C:\laragon\www\`.
2. Klik **Start All**.
3. Import SQL lewat **Database** (HeidiSQL) / phpMyAdmin, atau terminal:
   `mysql -u root < database/db_pemesanan_makanan.sql`
4. Buka `http://localhost/pesanan_makanan`.

> **Catatan:** Jika nama folder berbeda (misal `pemesanan-makanan`), ubah konstanta
> `BASE_URL` di `config/koneksi.php` menjadi `'/pemesanan-makanan'`.
> Jika password MySQL tidak kosong, ubah juga `$db_pass`.

## 🔄 Alur Kerja Aplikasi (untuk Pemula)

1. **Setiap halaman** memanggil `config/koneksi.php` → membuka koneksi database & session.
2. Halaman **memproses data dulu** (jika form dikirim / method POST), **baru menampilkan HTML**
   lewat `header.php` → isi halaman → `footer.php`.
3. **Data Menu**
   - `index.php` mengambil semua menu dengan `SELECT`.
   - `tambah.php` / `edit.php`: form → validasi (tidak boleh kosong, harus angka) →
     `INSERT` / `UPDATE` → simpan pesan sukses ke session → kembali ke daftar.
   - `hapus.php`: cek dulu apakah menu dipakai di pesanan (karena FOREIGN KEY).
     Jika tidak dipakai → `DELETE`.
4. **Data Pesanan**
   - `index.php` memakai `JOIN` agar yang tampil **nama menu**, bukan `id_menu`.
   - `tambah.php`: pilih menu → isi nama & jumlah → server cek `jumlah <= stok` →
     hitung `total_harga = harga × jumlah` → **kurangi stok** + simpan pesanan
     (dalam satu *transaksi*: berhasil semua atau batal semua).
   - `edit.php`: ubah jumlah/status → stok disesuaikan dengan selisihnya.
     Status **Dibatalkan** = stok dikembalikan.
   - `hapus.php`: muncul `confirm()` JavaScript → jika pesanan masih **Diproses**,
     stok dikembalikan → pesanan dihapus.
5. **Pesan sukses/gagal** disimpan di `$_SESSION['pesan']` lalu ditampilkan sekali
   oleh fungsi `tampil_pesan()` di header.

## 🔒 Keamanan yang Diterapkan
- **Prepared statement** (`mysqli_prepare` + `bind_param`) untuk semua query yang memakai input user → mencegah SQL Injection.
- **htmlspecialchars()** saat menampilkan data → mencegah XSS.
- Validasi di sisi server (bukan hanya di HTML/JavaScript).
